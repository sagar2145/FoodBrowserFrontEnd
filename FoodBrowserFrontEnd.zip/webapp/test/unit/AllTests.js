sap.ui.define([
	"com/sumit/project/FoodBrowser/test/unit/controller/Home.controller"
], function () {
	"use strict";
});