sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/m/MessageToast',
	"sap/ui/model/json/JSONModel", 'sap/m/MessageBox',
], function (Controller, MessageToast, JSONModel, MessageBox) {
	"use strict";
	var foodList = [];
	var customerEmail;
	var customerName;
	var customerPhone;
	var quantity;
	var price;
	var restaurantName;
	var restaurantAddress;
	var restaurantPhone;
	return Controller.extend("com.sumit.project.FoodBrowser.controller.Restraurant", {

		onInit: function () {
			var that = this;

			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.getRoute("Restraurant").attachMatched(this._onRouteMatched, this);
			this.oRouter.attachRoutePatternMatched(function (oEvent) {
				if (oEvent.getParameter("name") === "Restraurant") {
					that.restaurantGetData();
				}
			});

		},
		restaurantGetData: function () {
			var oRestraurantGetDataModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oRestraurantGetDataModel, "RestraurantListModel");
			oRestraurantGetDataModel.loadData("/postService/admin/getRest", null, true);
			oRestraurantGetDataModel.attachRequestCompleted(function (oEvent) {
				var RestaData = oEvent.getSource().getData();
				this.getView().getModel("RestraurantListModel").setProperty("/RestraurantList", RestaData);

			}.bind(this));
			oRestraurantGetDataModel.attachRequestFailed(function (oEvent) {
				// Error section
			});
		},
		_onRouteMatched: function (oEvent) {
			var oModel = this.getView().getModel("customerData");
			var email = oModel.oData.email;
			var oPostData = {
				"email": email
			};
			var oHeader = {
				"Content-Type": "application/json;charset=utf-8"
			};
			var oLoginUserDetailsDataModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oLoginUserDetailsDataModel, "oLoginUserDetailsDataModel");
			oLoginUserDetailsDataModel.loadData("/postService/customer/getCustBy", JSON.stringify(oPostData), true, "POST", false, false,
				oHeader);
			oLoginUserDetailsDataModel.attachRequestCompleted(function (oEvent) {

				var userData = oLoginUserDetailsDataModel.getData();
				var userName = userData.name;
				customerName = userData.name;
				customerEmail = userData.email;
				customerPhone = userData.phoneNo;

				this.getView().getModel("oLoginUserDetailsDataModel").setProperty("/userName", userName);
				// Welcome User Fragment
				var oFragmentName = "com.sumit.project.FoodBrowser.fragment.welcomeUser";
				var ofragId = "welcomeUser";
				if (!this.welcomeUserDialogFragment) {
					this.welcomeUserDialogFragment = this.createNewFragment(ofragId, oFragmentName);
					this.getView().addDependent(this.welcomeUserDialogFragment);
				}
				this.welcomeUserDialogFragment.open();
				setTimeout(function () {
					this.welcomeUserDialogFragment.close();
				}.bind(this), 1000);

			}.bind(this));
			oLoginUserDetailsDataModel.attachRequestFailed(function (oEvent) {
				//            alert("Error");
			});
			// OR var oModel = sap.ui.getCore().getModel("viewCartData");
		},
		addToCart: function (oEvent) {

			var oItem = oEvent.getSource().getBindingContext("oFoodListDataModel").getObject();
			foodList.push(oItem);
			MessageToast.show(oItem.foodName + " " + "Menu Added Into Cart");

		},
		onChangePassword: function () {

			var oFragmentName = "com.sumit.project.FoodBrowser.fragment.changePassword";
			var ofragId = "changePasswordFrag";
			if (!this.changePasswordDialogFragment) {
				this.changePasswordDialogFragment = this.createNewFragment(ofragId, oFragmentName);
				this.getView().addDependent(this.changePasswordDialogFragment);
			}
			this.changePasswordDialogFragment.open();

		},
		onCloseChangePassword: function () {

			sap.ui.core.Fragment.byId("changePasswordFrag", "OldPassword").setValue("");
			sap.ui.core.Fragment.byId("changePasswordFrag", "NewPassword").setValue("");
			sap.ui.core.Fragment.byId("changePasswordFrag", "CPassword").setValue("");
			this.changePasswordDialogFragment.close();
		},
		onChangePasswordSubmit: function () {
			var valid = true;
			var oldPassword = sap.ui.core.Fragment.byId("changePasswordFrag", "OldPassword").getValue();
			var newPassword = sap.ui.core.Fragment.byId("changePasswordFrag", "NewPassword").getValue();
			var confirmPassword = sap.ui.core.Fragment.byId("changePasswordFrag", "CPassword").getValue();

			if (oldPassword == "") {
				MessageToast.show("Old Password can not be empty");
				valid = false;
			}

			if (newPassword == "") {
				MessageToast.show("New Password can not be empty");
				valid = false;
			}
			if (confirmPassword == "") {
				MessageToast.show("Confirm Password can not be empty");
				valid = false;
			}

			if (newPassword != confirmPassword & confirmPassword != "" & newPassword != "") {
				MessageToast.show("Password does not match the confirm password.");
				valid = false;
			}
			if (valid == true) {
				this.changePasswordPostData();
			}
		},
		changePasswordPostData: function () {
			var oldPassword = sap.ui.core.Fragment.byId("changePasswordFrag", "OldPassword").getValue();
			var newPassword = sap.ui.core.Fragment.byId("changePasswordFrag", "NewPassword").getValue();

			oldPassword = window.btoa(oldPassword);
			newPassword = window.btoa(newPassword);

			var oPostData = {
				"passWord": oldPassword,
				"email": customerEmail,
				"newPass": newPassword
			};
			var oHeader = {
				"Content-Type": "application/json;charset=utf-8"
			};
			var oChangePasswordDataModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oChangePasswordDataModel, "oChangePasswordDataModel");
			oChangePasswordDataModel.loadData("/postService/customer/passUpdate", JSON.stringify(oPostData), true, "POST", false, false,
				oHeader);
			oChangePasswordDataModel.attachRequestCompleted(function (oEvent) {

				var checkStatus = oEvent.mParameters.errorobject.responseText;

				if (checkStatus == "password updated") {
					sap.ui.core.Fragment.byId("changePasswordFrag", "OldPassword").setValue("");
					sap.ui.core.Fragment.byId("changePasswordFrag", "NewPassword").setValue("");
					sap.ui.core.Fragment.byId("changePasswordFrag", "CPassword").setValue("");
					this.changePasswordDialogFragment.close();
					MessageToast.show("Your Password Successfully Updated");
				} else if (checkStatus == "enter correct password") {
					MessageToast.show("Old Password Not Corrent");
				} else {
					MessageToast.show("Somthing Went Wrong Please Try Again");
				}

			}.bind(this));
			oChangePasswordDataModel.attachRequestFailed(function (oEvent) {
				//            alert("Error");
			});
		},
		orderListWithCalculation: function () {
			var oOrderDetailsDataModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oOrderDetailsDataModel, "oOrderDetailsDataModel");
			this.getView().getModel("oOrderDetailsDataModel").setProperty("/orderList", foodList);
			quantity = foodList.length;

			var sum = 0
			for (var i = 0; i < foodList.length; i++) {
				var add = foodList[i].foodPrize;
				sum += parseInt(add);
			}
			price = sum;
			var oTotalDataModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oTotalDataModel, "oTotalDataModel");
			this.getView().getModel("oTotalDataModel").setProperty("/total", sum);
		},
		onOrder: function () {
			this.orderListWithCalculation();
			var oFragmentName = "com.sumit.project.FoodBrowser.fragment.order";
			var ofragId = "orderFrag";
			if (!this.orderDialogFragment) {
				this.orderDialogFragment = this.createNewFragment(ofragId, oFragmentName);
				this.getView().addDependent(this.orderDialogFragment);
			}
			this.orderDialogFragment.open();

		},
		removeItem: function (oEvent) {
			var oItem = oEvent.getSource().getBindingContext("oOrderDetailsDataModel").getObject();

			var index = foodList.indexOf(oItem);
			if (index > -1) {
				foodList.splice(index, 1);
			}
			this.orderListWithCalculation();
		},
		onCloseOrder: function () {
			foodList = [];
			this.orderDialogFragment.close();
		},
		onCloseFoodList: function () {
			this.FoodMenuDialogFrag.close();
		},
		onPlaceOrder: function () {
			var customerAddress = sap.ui.core.Fragment.byId("orderFrag", "address").getValue();

			var valid = true;
			if (customerAddress == "") {
				MessageToast.show("Custumer Address Can't Be Empty");
				valid = false;
			}
			if (foodList.length <= 0) {
				MessageToast.show("Must Select Food Items");
				valid = false;
			}

			if (valid == true) {
				this.placeOrderPostData();
			}

		},
		placeOrderPostData: function () {
			var customerAddress = sap.ui.core.Fragment.byId("orderFrag", "address").getValue();
			var Items = [];
			for (var i = 0; i < foodList.length; i++) {
				var menu = foodList[i].foodName;
				Items.push(menu);
			}
			// Items.push(foodList.foodName);
			Items = Items.toString();
			var oPostData = {
				"customerEmail": customerEmail,
				"customerName": customerName,
				"customerPhone": customerPhone,
				"customerAddress": customerAddress,
				"quantity": quantity,
				"price": price,
				"items": Items,
				"restaurantName": restaurantName,
				"restaurantAddress": restaurantAddress,
				"restaurantPhone": restaurantPhone
			};
			var oHeader = {
				"Content-Type": "application/json;charset=utf-8"
			};
			var oOrderPlaceDataModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oOrderPlaceDataModel, "oOrderPlaceDataModel");
			oOrderPlaceDataModel.loadData("/postService/admin/setOrder", JSON.stringify(oPostData), true, "POST", false, false, oHeader);
			oOrderPlaceDataModel.attachRequestCompleted(function (oEvent) {

				var checkStatus = oEvent.mParameters.errorobject.responseText;

				if (checkStatus == "order placed") {
					foodList = [];
					sap.ui.core.Fragment.byId("orderFrag", "address").setValue("");
					this.orderDialogFragment.close();
					this.FoodMenuDialogFrag.close();
					MessageToast.show("Successfully Order Placed");
				} else {
					MessageToast.show("Somthing Went Wrong");
				}

			}.bind(this));
			oOrderPlaceDataModel.attachRequestFailed(function (oEvent) {
				//            alert("Error");
			});
		},
		deleteCustomerBtn: function () {
			var that = this;
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			MessageBox.confirm(
				"Are you sure to delete account", {
					styleClass: bCompact ? "sapUiSizeCompact" : "",
					onClose: function (sAction) {

						if (sAction === "OK") {
							that.deleteCustPostData();
						}

					}
				}
			);

		},
		deleteCustPostData: function () {

			var oPostData = {
				"email": customerEmail
			};
			var oHeader = {
				"Content-Type": "application/json;charset=utf-8"
			};
			var oDeleteCustaSendDataModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oDeleteCustaSendDataModel, "oDeleteCustaSendDataModel");
			oDeleteCustaSendDataModel.loadData("/postService/customer/deleteCust", JSON.stringify(oPostData), true, "POST", false, false,
				oHeader);
			oDeleteCustaSendDataModel.attachRequestCompleted(function (oEvent) {

				var checkStatus = oEvent.mParameters.errorobject.responseText;

				if (checkStatus == "customer deleted") {
					this.oRouter.navTo("RouteHome");
					MessageToast.show("Customer Deleted Successfully");

				} else {
					MessageToast.show("Somthing is Wrong Please Try Again");
				}

			}.bind(this));
			oDeleteCustaSendDataModel.attachRequestFailed(function (oEvent) {
				//            alert("Error");
			});
		},
		onFoodMenuBtn: function (oEvent) {
			var oItem = oEvent.getSource().getBindingContext("RestraurantListModel").getObject();
			var restaurantId = oItem.restaurantId;
			restaurantName = oItem.restaurantName;
			restaurantAddress = oItem.restaurantAddress;
			restaurantPhone = oItem.restaurantPhone;
			// Food Menu Fragment

			var oPostData = {
				"restaurantId": restaurantId
			};
			var oHeader = {
				"Content-Type": "application/json;charset=utf-8"
			};
			var oFoodListDataModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oFoodListDataModel, "oFoodListDataModel");
			oFoodListDataModel.loadData("/postService/admin/getFoodList", JSON.stringify(oPostData), true, "POST", false, false, oHeader);
			oFoodListDataModel.attachRequestCompleted(function (oEvent) {

				var userData = oFoodListDataModel.getData();
				this.getView().getModel("oFoodListDataModel").setProperty("/foodItems", userData);

			}.bind(this));
			oFoodListDataModel.attachRequestFailed(function (oEvent) {
				//            alert("Error");
			});

			var oFragmentName = "com.sumit.project.FoodBrowser.fragment.foodItems";
			var ofragId = "FoodMenuDialogFrag";
			if (!this.FoodMenuDialogFrag) {
				this.FoodMenuDialogFrag = this.createNewFragment(ofragId, oFragmentName);
				this.getView().addDependent(this.FoodMenuDialogFrag);
			}

			this.FoodMenuDialogFrag.open();

		}, //onDriverRegisterBtn End
		onLogOut: function () {
			this.oRouter.navTo("RouteHome");
			MessageToast.show("Successfully LogOut");
		},
		createNewFragment: function (sFragmentID, sFragmentName) {
			// Create Fragment 
			var oFragment = sap.ui.xmlfragment(sFragmentID, sFragmentName, this);
			return oFragment;
		}, //createNewFragment End

	});

});