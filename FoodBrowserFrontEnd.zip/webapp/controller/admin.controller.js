sap.ui.define([
	'jquery.sap.global',
	'sap/m/MessageToast',
	'sap/ui/core/Fragment',
	'sap/ui/core/mvc/Controller',
	'sap/ui/model/Filter',
	'sap/ui/model/json/JSONModel',
	'sap/base/Log'
], function (jQuery, MessageToast, Fragment, Controller, Filter, JSONModel, Log) {
	"use strict";
	var driverEmail;
	return Controller.extend("com.sumit.project.FoodBrowser.controller.admin", {

		onInit: function () {
			var that = this;
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.attachRoutePatternMatched(function (oEvent) {
				if (oEvent.getParameter("name") === "Admin") {
					that.RestaGetData();
					that.DriverListGetData();
					that.AllDriverListGetData();
					that.OrderListGetData();
					that.CustomerDetailsGetData();
				}
			});

		},
		RestaGetData: function () {
			var oRestraurantGetDataModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oRestraurantGetDataModel, "RestraurantListModel");
			oRestraurantGetDataModel.loadData("/postService/admin/getRest", null, true);
			oRestraurantGetDataModel.attachRequestCompleted(function (oEvent) {

				var RestaData = oEvent.getSource().getData();
				this.getView().getModel("RestraurantListModel").setData(RestaData);

			}.bind(this));
			oRestraurantGetDataModel.attachRequestFailed(function (oEvent) {
				// Error section
			});

		},
		onDriverRegisterBtn: function () {
			//bind(this); 
			// CheckOut Fragment
			var oFragmentName = "com.sumit.project.FoodBrowser.fragment.driverRegister";
			var ofragId = "DriverRegisterFrag";
			if (!this.DriverRegDialogFragment) {
				this.DriverRegDialogFragment = this.createNewFragment(ofragId, oFragmentName);
				this.getView().addDependent(this.DriverRegDialogFragment);
			}

			this.DriverRegDialogFragment.open();

		}, //onDriverRegisterBtn End
		onCloseDriverRegiter: function () {
			sap.ui.core.Fragment.byId("DriverRegisterFrag", "name").setValue("");
			sap.ui.core.Fragment.byId("DriverRegisterFrag", "phone").setValue("");
			sap.ui.core.Fragment.byId("DriverRegisterFrag", "email").setValue("");
			sap.ui.core.Fragment.byId("DriverRegisterFrag", "Password").setValue("");
			sap.ui.core.Fragment.byId("DriverRegisterFrag", "CPassword").setValue("");
			sap.ui.core.Fragment.byId("DriverRegisterFrag", "licenceNo").setValue("");
			this.DriverRegDialogFragment.close();
		},
		onDriverRegisterSubmit: function () {
			// Form Validation
			var valid = true; //  

			this.numericRegularExpression = /([0-9])/;

			// Name Field Validation
			var name = sap.ui.core.Fragment.byId("DriverRegisterFrag", "name").getValue();
			if (name == "") {
				MessageToast.show("Name can not be empty");
				valid = false;
			}
			if (!isNaN(name)) {
				MessageToast.show("Name can not have a number");

				valid = false;
			}
			if (this.numericRegularExpression.test(name)) {
				MessageToast.show("Alphanumeric Name is not allowed");

				valid = false;
			}

			// Email Field Validation
			var email = sap.ui.core.Fragment.byId("DriverRegisterFrag", "email").getValue();
			if (email === "") {
				MessageToast.show("Email cant be empty");

				valid = false;
			} else if (/^[a-zA-Z0-9]+$/.test(email)) {
				MessageToast.show("Email should have @ character");

				valid = false;
			} else if (/^([a-zA-Z0-9@]{2,5})$/.test(email)) {
				MessageToast.show("Email should have 2 char after @ symbol");

				valid = false;
			} else if (/^([a-zA-Z0-9_\@]+)$/.test(email)) {
				MessageToast.show("Email should have . symbol");

				valid = false;
			}
			// Email Regular Expression
			var emailRegularExpression =
				/^(([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5}){1,25})+([;.](([a-zA-Z0-9_\-\.]+)@{[a-zA-Z0-9_\-\.]+0\.([a-zA-Z]{2,5}){1,25})+)*$/;
			if (emailRegularExpression.test(email) === false) {
				MessageToast.show("Email should have 2 char after . symbol");

				valid = false;
			}

			// Phone Number Validation
			var phone = sap.ui.core.Fragment.byId("DriverRegisterFrag", "phone").getValue();
			if (phone === "") {
				MessageToast.show("phone no. cann't be empty");

				valid = false;
			}
			var numericRegularExpression = /^[0][1-9]\d{9}$|^[1-9]\d{9}$/;
			if (numericRegularExpression.test(phone) === false) {
				MessageToast.show("phone number should have only 10 digits");

				valid = false;
			}

			var licenceNo = sap.ui.core.Fragment.byId("DriverRegisterFrag", "licenceNo").getValue();
			if (licenceNo == "") {
				MessageToast.show("Licence number can not be empty");
				valid = false;
			}

			var licenceRegularExpression = /^[A-Z]{2}\d{2}\d{4}\d{7}$/;
			if (licenceRegularExpression.test(licenceNo) === false) {
				MessageToast.show("Enter Valid Driving Licence Number ");
				valid = false;
			}

			var password = sap.ui.core.Fragment.byId("DriverRegisterFrag", "Password").getValue();
			var confirmPassword = sap.ui.core.Fragment.byId("DriverRegisterFrag", "CPassword").getValue();
			if (password == "") {
				MessageToast.show("Password can not be empty");
				valid = false;
			}
			if (password.length < 5) {
				MessageToast.show("Password Should Contain atleast 5 characters");
				valid = false;
			}
			if (password.length > 15) {
				MessageToast.show("Password Should Contain only 15 characters");
				valid = false;
			}
			if (confirmPassword == "") {
				MessageToast.show("Confirm Password can not be empty");
				valid = false;
			}

			if (password != confirmPassword & confirmPassword != "" & password != "") {
				MessageToast.show("Password does not match the confirm password.");
				valid = false;
			}

			if (valid == true) {
				this.DriverRegisterPostData();
			}

		},

		DriverRegisterPostData: function () {
			// Sending Data to backend LoadData Function
			var Name = sap.ui.core.Fragment.byId("DriverRegisterFrag", "name").getValue();
			var phone = sap.ui.core.Fragment.byId("DriverRegisterFrag", "phone").getValue();
			var email = sap.ui.core.Fragment.byId("DriverRegisterFrag", "email").getValue();
			var password = sap.ui.core.Fragment.byId("DriverRegisterFrag", "Password").getValue();
			var licenceNo = sap.ui.core.Fragment.byId("DriverRegisterFrag", "licenceNo").getValue();
			var ePass = window.btoa(password);
			var oPostData = {
				"driverName": Name,
				"phone": phone,
				"email": email,
				"password": ePass,
				"licenceNo": licenceNo
			};
			var oHeader = {
				"Content-Type": "application/json;charset=utf-8"
			};
			var oDriverRegSendDataModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oDriverRegSendDataModel, "oDriverRegSendDataModel");
			oDriverRegSendDataModel.loadData("/postService/driver/save", JSON.stringify(oPostData), true, "POST", false, false, oHeader);
			oDriverRegSendDataModel.attachRequestCompleted(function (oEvent) {

				var checkStatus = oEvent.mParameters.errorobject.responseText;

				if (checkStatus == "driver added") {
					sap.ui.core.Fragment.byId("DriverRegisterFrag", "name").setValue("");
					sap.ui.core.Fragment.byId("DriverRegisterFrag", "phone").setValue("");
					sap.ui.core.Fragment.byId("DriverRegisterFrag", "email").setValue("");
					sap.ui.core.Fragment.byId("DriverRegisterFrag", "Password").setValue("");
					sap.ui.core.Fragment.byId("DriverRegisterFrag", "CPassword").setValue("");
					sap.ui.core.Fragment.byId("DriverRegisterFrag", "licenceNo").setValue("");
					this.AllDriverListGetData();
					this.DriverRegDialogFragment.close();
					MessageToast.show("Successfully Register");
				} else if (checkStatus == " Driver already exists") {
					MessageToast.show("Driver already exists");
				} else {
					MessageToast.show("Somthing is wrong plese try again");
				}

			}.bind(this));
			oDriverRegSendDataModel.attachRequestFailed(function (oEvent) {
				//            alert("Error");
			});

		}, //postData End

		DriverListGetData: function () {
			var oDriverListGetDataModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oDriverListGetDataModel, "oDriverListGetDataModel");
			oDriverListGetDataModel.loadData("/postService/driver/getDrivByIfNoOrder", null, true);
			oDriverListGetDataModel.attachRequestCompleted(function (oEvent) {
				var DriverData = oEvent.getSource().getData();
				this.getView().getModel("oDriverListGetDataModel").setProperty("/DriverList", DriverData);

			}.bind(this));
			oDriverListGetDataModel.attachRequestFailed(function (oEvent) {
				// Error section
			});
		},
		AllDriverListGetData: function () {
			var oAllDriverListGetDataModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oAllDriverListGetDataModel, "oAllDriverListGetDataModel");
			oAllDriverListGetDataModel.loadData("/postService/driver/getdriv", null, true);
			oAllDriverListGetDataModel.attachRequestCompleted(function (oEvent) {
				var AllDriverData = oEvent.getSource().getData();
				this.getView().getModel("oAllDriverListGetDataModel").setProperty("/AllDriverList", AllDriverData);

			}.bind(this));
			oAllDriverListGetDataModel.attachRequestFailed(function (oEvent) {
				// Error section
			});
		},
		CustomerDetailsGetData: function () {
			var oCustomerDetailsGetDataModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oCustomerDetailsGetDataModel, "oCustomerDetailsGetDataModel");
			oCustomerDetailsGetDataModel.loadData("/postService/customer/getcust", null, true);
			oCustomerDetailsGetDataModel.attachRequestCompleted(function (oEvent) {
				var AllCusyomerData = oEvent.getSource().getData();
				this.getView().getModel("oCustomerDetailsGetDataModel").setProperty("/AllCustomerList", AllCusyomerData);

			}.bind(this));
			oCustomerDetailsGetDataModel.attachRequestFailed(function (oEvent) {
				// Error section
			});
		},
		OrderListGetData: function () {
			var oOrderListGetDataModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oOrderListGetDataModel, "oOrderListGetDataModel");
			oOrderListGetDataModel.loadData("/postService/admin/getorder", null, true);
			oOrderListGetDataModel.attachRequestCompleted(function (oEvent) {
				var OrderData = oEvent.getSource().getData();
				this.getView().getModel("oOrderListGetDataModel").setProperty("/OrderData", OrderData);

			}.bind(this));
			oOrderListGetDataModel.attachRequestFailed(function (oEvent) {
				// Error section
			});
		},

		driverDeleteBtn: function (oEvent) {
			var oItem = oEvent.getSource().getBindingContext("oAllDriverListGetDataModel").getObject();
			var email = oItem.email;

			var oPostData = {
				"email": email
			};
			var oHeader = {
				"Content-Type": "application/json;charset=utf-8"
			};
			var oDeleteDriverSendDataModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oDeleteDriverSendDataModel, "oDeleteDriverSendDataModel");
			oDeleteDriverSendDataModel.loadData("/postService/driver/deleteDriv", JSON.stringify(oPostData), true, "POST", false, false,
				oHeader);
			oDeleteDriverSendDataModel.attachRequestCompleted(function (oEvent) {

				var checkStatus = oEvent.mParameters.errorobject.responseText;

				if (checkStatus == "driver deleted") {

					this.AllDriverListGetData();
					MessageToast.show("Driver Deleted Successfully");

				} else {
					MessageToast.show("Somthing is Wrong Please Try Again");
				}

			}.bind(this));
			oDeleteDriverSendDataModel.attachRequestFailed(function (oEvent) {
				//            alert("Error");
			});

		},
		onAddMenuRestaurantBtn: function () {
			var oFragmentName = "com.sumit.project.FoodBrowser.fragment.addMenuToRestaurant";
			var ofragId = "addMenuToRestaurantFrag";
			if (!this.addMenuToRestaurantDialogFragment) {
				this.addMenuToRestaurantDialogFragment = this.createNewFragment(ofragId, oFragmentName);
				this.getView().addDependent(this.addMenuToRestaurantDialogFragment);
			}

			this.addMenuToRestaurantDialogFragment.open();
		},
		onCloseAddMenuRestaurant: function () {
			this.addMenuToRestaurantDialogFragment.close();
		},
		onAddMenuToRestaurantSubmit: function () {

			var valid = true;
			var Name = sap.ui.core.Fragment.byId("addMenuToRestaurantFrag", "Name").getValue();
			var restarant = sap.ui.core.Fragment.byId("addMenuToRestaurantFrag", "restaurant").getSelectedKey();
			var price = sap.ui.core.Fragment.byId("addMenuToRestaurantFrag", "price").getValue();
			if (Name == "") {
				MessageToast.show("Menu Name Can't be empty");
				valid = false;
			}
			if (price == "") {
				MessageToast.show("Menu Price Can't be empty");
				valid = false;
			}
			if (restarant == "") {
				MessageToast.show("Please Select Restaurant From Given List");
				valid = false;
			}
			if (valid == true) {
				this.AddMenuToRestaurantPostData();
			}
		},
		AddMenuToRestaurantPostData: function () {
			var Name = sap.ui.core.Fragment.byId("addMenuToRestaurantFrag", "Name").getValue();
			var restarantId = sap.ui.core.Fragment.byId("addMenuToRestaurantFrag", "restaurant").getSelectedKey();
			var price = sap.ui.core.Fragment.byId("addMenuToRestaurantFrag", "price").getValue();
			var oPostData = {
				"restaurantId": restarantId,
				"foodList": [{
					"foodName": Name,
					"foodPrize": price
				}]
			};
			var oHeader = {
				"Content-Type": "application/json;charset=utf-8"
			};
			var oAddMenuToRestaSendDataModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oAddMenuToRestaSendDataModel, "oAddMenuToRestaSendDataModel");
			oAddMenuToRestaSendDataModel.loadData("/postService/admin/addFood", JSON.stringify(oPostData), true, "POST", false, false, oHeader);
			oAddMenuToRestaSendDataModel.attachRequestCompleted(function (oEvent) {

				var checkStatus = oEvent.mParameters.errorobject.responseText;

				if (checkStatus == "item(s) added") {
					sap.ui.core.Fragment.byId("addMenuToRestaurantFrag", "Name").setValue("");
					sap.ui.core.Fragment.byId("addMenuToRestaurantFrag", "price").setValue("");
					this.addMenuToRestaurantDialogFragment.close();
					MessageToast.show("Food Item Added Successfully");

				} else {
					MessageToast.show("Somthing is Wrong Please Try Again");
				}

			}.bind(this));
			oAddMenuToRestaSendDataModel.attachRequestFailed(function (oEvent) {
				//            alert("Error");
			});
		},
		deleteRestaurant: function (oEvent) {
			var oItem = oEvent.getSource().getBindingContext("RestraurantListModel").getObject();
			var restaurantId = oItem.restaurantId;

			var oPostData = {
				"restaurantId": restaurantId,
			};
			var oHeader = {
				"Content-Type": "application/json;charset=utf-8"
			};
			var oDeleteRestaSendDataModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oDeleteRestaSendDataModel, "oDeleteRestaSendDataModel");
			oDeleteRestaSendDataModel.loadData("/postService/admin/deleteRest", JSON.stringify(oPostData), true, "POST", false, false, oHeader);
			oDeleteRestaSendDataModel.attachRequestCompleted(function (oEvent) {

				var checkStatus = oEvent.mParameters.errorobject.responseText;

				if (checkStatus == "deleted") {

					this.RestaGetData();
					MessageToast.show("Restaurant Successfully Deleted");

				} else {
					MessageToast.show("Somthing is Wrong Please Try Again");
				}

			}.bind(this));
			oDeleteRestaSendDataModel.attachRequestFailed(function (oEvent) {
				//            alert("Error");
			});
		},
		editRestaurant: function (oEvent) {

			var oItem = oEvent.getSource().getBindingContext("RestraurantListModel").getObject();
			var restaId = oItem.restaurantId;
			var restaName = oItem.restaurantName;
			var restaPhone = oItem.restaurantPhone;
			var restaRating = oItem.rating;
			var restaurantAddress = oItem.restaurantAddress;

			var oFragmentName = "com.sumit.project.FoodBrowser.fragment.editRestaurant";
			var ofragId = "editRestaurantFrag";
			if (!this.editRestaurantDialogFragment) {
				this.editRestaurantDialogFragment = this.createNewFragment(ofragId, oFragmentName);
				this.getView().addDependent(this.editRestaurantDialogFragment);
			}

			this.editRestaurantDialogFragment.open();
			sap.ui.core.Fragment.byId("editRestaurantFrag", "restId").setValue(restaId);
			sap.ui.core.Fragment.byId("editRestaurantFrag", "name").setValue(restaName);
			sap.ui.core.Fragment.byId("editRestaurantFrag", "phone").setValue(restaPhone);
			sap.ui.core.Fragment.byId("editRestaurantFrag", "address").setValue(restaurantAddress);
			sap.ui.core.Fragment.byId("editRestaurantFrag", "rating").setValue(restaRating);

		},
		onCloseEditRestaurant: function () {
			this.editRestaurantDialogFragment.close();
		},
		onLogOut: function () {
			this.oRouter.navTo("RouteHome");
			MessageToast.show("Successfully LogOut");
		},
		onEditRestaurantSubmit: function () {
			var valid = true;
			var Name = sap.ui.core.Fragment.byId("editRestaurantFrag", "name").getValue();
			//	var image = sap.ui.core.Fragment.byId("editRestaurantFrag", "image").getValue();
			var phone = sap.ui.core.Fragment.byId("editRestaurantFrag", "phone").getValue();
			var address = sap.ui.core.Fragment.byId("editRestaurantFrag", "address").getValue();
			var rating = sap.ui.core.Fragment.byId("editRestaurantFrag", "rating").getValue();
			//var restaId = sap.ui.core.Fragment.byId("editRestaurantFrag", "restId").getValue();

			if (Name == "") {
				MessageToast.show("Restaurant Name Can't be empty");
				valid = false;
			}
			if (!isNaN(Name)) {
				MessageToast.show("Name can not have a number");

				valid = false;
			}

			// Phone Number Validation
			if (phone === "") {
				MessageToast.show("phone no. cann't be empty");

				valid = false;
			}
			var numericRegularExpression = /^[0][1-9]\d{9}$|^[1-9]\d{9}$/;
			if (numericRegularExpression.test(phone) === false) {
				MessageToast.show("phone number should have only 10 digits");

				valid = false;
			}

			if (address == "") {
				MessageToast.show("Restaurant Address Can't be empty");
				valid = false;
			}

			if (rating == "") {
				MessageToast.show("Restaurant Rating Can't be empty");
				valid = false;
			}

			if (valid == true) {
				this.EditRestaurantPostData();
			}

		},
		EditRestaurantPostData: function () {
			var Name = sap.ui.core.Fragment.byId("editRestaurantFrag", "name").getValue();
			//	var image = sap.ui.core.Fragment.byId("editRestaurantFrag", "image").getValue();
			var phone = sap.ui.core.Fragment.byId("editRestaurantFrag", "phone").getValue();
			var address = sap.ui.core.Fragment.byId("editRestaurantFrag", "address").getValue();
			var rating = sap.ui.core.Fragment.byId("editRestaurantFrag", "rating").getValue();
			var restaId = sap.ui.core.Fragment.byId("editRestaurantFrag", "restId").getValue();

			var oFileUploader = sap.ui.core.Fragment.byId("editRestaurantFrag", "fileUploader");
			var imageValue = oFileUploader.getValue();

			var oPostData = {
				"restaurantId": restaId,
				"restaurantName": Name,
				"restaurantAddress": address,
				"rating": rating,
				"restaurantPhone": phone,
				"image": imageValue
			};
			var oHeader = {
				"Content-Type": "application/json;charset=utf-8"
			};
			var oEditRestaSendDataModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oEditRestaSendDataModel, "oEditRestaSendDataModel");
			oEditRestaSendDataModel.loadData("/postService/admin/editRest", JSON.stringify(oPostData), true, "POST", false, false, oHeader);
			oEditRestaSendDataModel.attachRequestCompleted(function (oEvent) {

				var checkStatus = oEvent.mParameters.errorobject.responseText;

				if (checkStatus == "restaurant updated") {
					sap.ui.core.Fragment.byId("editRestaurantFrag", "name").setValue("");
					sap.ui.core.Fragment.byId("editRestaurantFrag", "phone").setValue("");
					sap.ui.core.Fragment.byId("editRestaurantFrag", "address").setValue("");
					sap.ui.core.Fragment.byId("editRestaurantFrag", "rating").setValue("");
					sap.ui.core.Fragment.byId("editRestaurantFrag", "restId").setValue("");
					this.editRestaurantDialogFragment.close();
					this.RestaGetData();
					MessageToast.show("Restaurant Successfully Updated");

				} else {
					MessageToast.show("Somthing is Wrong Please Try Again");
				}

			}.bind(this));
			oEditRestaSendDataModel.attachRequestFailed(function (oEvent) {
				//            alert("Error");
			});

		},
		onAddRestaurantBtn: function () {

			var oFragmentName = "com.sumit.project.FoodBrowser.fragment.addRestaurant";
			var ofragId = "addRestaurantFrag";
			if (!this.addRestaurantDialogFragment) {
				this.addRestaurantDialogFragment = this.createNewFragment(ofragId, oFragmentName);
				this.getView().addDependent(this.addRestaurantDialogFragment);
			}

			this.addRestaurantDialogFragment.open();

		},

		onAddRestaurantSubmit: function () {
			var valid = true;
			var Name = sap.ui.core.Fragment.byId("addRestaurantFrag", "name").getValue();
			var phone = sap.ui.core.Fragment.byId("addRestaurantFrag", "phone").getValue();
			var address = sap.ui.core.Fragment.byId("addRestaurantFrag", "address").getValue();
			var rating = sap.ui.core.Fragment.byId("addRestaurantFrag", "rating").getValue();

			if (Name == "") {
				MessageToast.show("Restaurant Name Can't be empty");
				valid = false;
			}
			if (!isNaN(Name)) {
				MessageToast.show("Name can not have a number");

				valid = false;
			}

			// Phone Number Validation
			if (phone === "") {
				MessageToast.show("phone no. cann't be empty");

				valid = false;
			}
			var numericRegularExpression = /^[0][1-9]\d{9}$|^[1-9]\d{9}$/;
			if (numericRegularExpression.test(phone) === false) {
				MessageToast.show("phone number should have only 10 digits");

				valid = false;
			}

			if (address == "") {
				MessageToast.show("Restaurant Address Can't be empty");
				valid = false;
			}

			if (rating == "") {
				MessageToast.show("Restaurant Rating Can't be empty");
				valid = false;
			}

			if (valid == true) {
				this.addRestaurantPostData();
			}

		},
		addRestaurantPostData: function () {
			var Name = sap.ui.core.Fragment.byId("addRestaurantFrag", "name").getValue();
			var phone = sap.ui.core.Fragment.byId("addRestaurantFrag", "phone").getValue();
			var address = sap.ui.core.Fragment.byId("addRestaurantFrag", "address").getValue();
			var rating = sap.ui.core.Fragment.byId("addRestaurantFrag", "rating").getValue();
			var oFileUploader = sap.ui.core.Fragment.byId("addRestaurantFrag", "fileUploader");
			var imageValue = oFileUploader.getValue();
			//var eImage = window.btoa(imageValue);

			var oPostData = {
				"restaurantName": Name,
				"restaurantAddress": address,
				"rating": rating,
				"restaurantPhone": phone,
				"image": imageValue,
			};
			var oHeader = {
				"Content-Type": "application/json;charset=utf-8"
			};
			var oAddRestaSendDataModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oAddRestaSendDataModel, "oEditRestaSendDataModel");
			oAddRestaSendDataModel.loadData("/postService/admin/addRest", JSON.stringify(oPostData), true, "POST", false, false, oHeader);
			oAddRestaSendDataModel.attachRequestCompleted(function (oEvent) {

				var checkStatus = oEvent.mParameters.errorobject.responseText;

				if (checkStatus == "restaurant added") {
					sap.ui.core.Fragment.byId("addRestaurantFrag", "name").setValue("");
					sap.ui.core.Fragment.byId("addRestaurantFrag", "phone").setValue("");
					sap.ui.core.Fragment.byId("addRestaurantFrag", "address").setValue("");
					sap.ui.core.Fragment.byId("addRestaurantFrag", "rating").setValue("");
					this.addRestaurantDialogFragment.close();
					this.RestaGetData();
					MessageToast.show("Successfully Added");
				} else {
					MessageToast.show("Somthing is Wrong Please Try Again");
				}

			}.bind(this));
			oAddRestaSendDataModel.attachRequestFailed(function (oEvent) {
				//            alert("Error");
			});

		},

		onAssignOrderBtn: function (oEvent) {

			var oItem = oEvent.getSource().getBindingContext("oOrderListGetDataModel").getObject();
			var OrderId = oItem.orderId;
			var CustPhone = oItem.customerPhone;
			var RestaPhone = oItem.restaurantPhone;

			var oPostData = {
				"orderId": OrderId,
				"driverEmail": driverEmail,
				"restaurantPhone": RestaPhone,
				"customerPhone": CustPhone
			};
			var oHeader = {
				"Content-Type": "application/json;charset=utf-8"
			};
			var oAssignOrderSendDataModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oAssignOrderSendDataModel, "oAssignOrderSendDataModel");
			oAssignOrderSendDataModel.loadData("/postService/admin/assignOrder", JSON.stringify(oPostData), true, "POST", false, false,
				oHeader);
			oAssignOrderSendDataModel.attachRequestCompleted(function (oEvent) {

				var checkStatus = oEvent.mParameters.errorobject.responseText;

				if (checkStatus == "order assigned") {
					this.DriverListGetData();
					this.OrderListGetData();
					MessageToast.show("Successfully order assigned");
				} else if (checkStatus == "already assigned") {
					MessageToast.show("Order Is Already Assign To Driver Or It's delivered Check Status");
				} else {
					MessageToast.show("Somthing is Wrong Please Try Again");
				}

			}.bind(this));
			oAssignOrderSendDataModel.attachRequestFailed(function (oEvent) {
				//            alert("Error");
			});

		},
		selectionChange: function (oEvent) {
			var selval = oEvent.getParameter("selectedItem").getBindingContext("oDriverListGetDataModel").getObject();
			driverEmail = selval.email;
		},

		onCloseAddRestaurant: function () {
			sap.ui.core.Fragment.byId("addRestaurantFrag", "name").setValue("");
			sap.ui.core.Fragment.byId("addRestaurantFrag", "phone").setValue("");
			sap.ui.core.Fragment.byId("addRestaurantFrag", "address").setValue("");
			sap.ui.core.Fragment.byId("addRestaurantFrag", "rating").setValue("");
			this.addRestaurantDialogFragment.close();
		},
		createNewFragment: function (sFragmentID, sFragmentName) {
			// Create Fragment 
			var oFragment = sap.ui.xmlfragment(sFragmentID, sFragmentName, this);
			return oFragment;
		}, //createNewFragment End

		onOrientationChange: function (oEvent) {
			var bLandscapeOrientation = oEvent.getParameter("landscape"),
				sMsg = "Orientation now is: " + (bLandscapeOrientation ? "Landscape" : "Portrait");
			MessageToast.show(sMsg, {
				duration: 5000
			});
		},

		onPressNavToDetail: function (oEvent) {
			this.getSplitAppObj().to(this.createId("detailDetail"));
		},

		onPressDetailBack: function () {
			this.getSplitAppObj().backDetail();
		},

		onPressMasterBack: function () {
			this.getSplitAppObj().backMaster();
		},

		onPressGoToMaster: function () {
			this.getSplitAppObj().toMaster(this.createId("master2"));
		},

		onListItemPress: function (oEvent) {
			var sToPageId = oEvent.getParameter("listItem").getCustomData()[0].getValue();

			this.getSplitAppObj().toDetail(this.createId(sToPageId));
		},

		onPressModeBtn: function (oEvent) {
			var sSplitAppMode = oEvent.getSource().getSelectedButton().getCustomData()[0].getValue();

			this.getSplitAppObj().setMode(sSplitAppMode);
			MessageToast.show("Split Container mode is changed to: " + sSplitAppMode, {
				duration: 5000
			});
		},

		getSplitAppObj: function () {
			var result = this.byId("SplitAppDemo");
			if (!result) {
				Log.info("SplitApp object can't be found");
			}
			return result;
		}

	});

});