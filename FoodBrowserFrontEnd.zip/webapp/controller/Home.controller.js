sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/m/MessageToast'
], function (Controller, MessageToast) {
	"use strict";

	return Controller.extend("com.sumit.project.FoodBrowser.controller.Home", {
		onInit: function () {
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.attachRoutePatternMatched(function (oEvent) {
				if (oEvent.getParameter("name") === "RouteHome") {

				}
			});

		},
		onCustomerRegisterBtn: function () {

			// Customer Registration Fragment
			var oFragmentName = "com.sumit.project.FoodBrowser.fragment.customerRegisterForm";
			var ofragId = "CustomerRegisterFrag";
			if (!this.CustomerRegDialogFragment) {
				this.CustomerRegDialogFragment = this.createNewFragment(ofragId, oFragmentName);
				this.getView().addDependent(this.CustomerRegDialogFragment);
			}

			this.CustomerRegDialogFragment.open();

		}, //onCustomerRegisterBtn End

		onDriverLogin: function () {
			var oFragmentName = "com.sumit.project.FoodBrowser.fragment.driverLogin";
			var ofragId = "DriverLoginFrag";
			if (!this.DriverLoginDialogFragment) {
				this.DriverLoginDialogFragment = this.createNewFragment(ofragId, oFragmentName);
				this.getView().addDependent(this.DriverLoginDialogFragment);
			}

			this.DriverLoginDialogFragment.open();

		},
		onCloseDriverLogin: function () {
			sap.ui.core.Fragment.byId("DriverLoginFrag", "email").setValue("");
			sap.ui.core.Fragment.byId("DriverLoginFrag", "Password").setValue("");
			this.DriverLoginDialogFragment.close();
		},
		onAdminLogin: function () {
			var oFragmentName = "com.sumit.project.FoodBrowser.fragment.adminLogin";
			var ofragId = "AdminLoginFrag";
			if (!this.AdminLoginDialogFragment) {
				this.AdminLoginDialogFragment = this.createNewFragment(ofragId, oFragmentName);
				this.getView().addDependent(this.AdminLoginDialogFragment);
			}

			this.AdminLoginDialogFragment.open();

		},
		onAdminCloseLogin: function () {
			sap.ui.core.Fragment.byId("AdminLoginFrag", "email").setValue("");
			sap.ui.core.Fragment.byId("AdminLoginFrag", "Password").setValue("");
			this.AdminLoginDialogFragment.close();
		},
		onCustomerLogin: function () {
			// CheckOut Fragment
			var oFragmentName = "com.sumit.project.FoodBrowser.fragment.logIn";
			var ofragId = "LoginFrag";
			if (!this.LoginFrag) {
				this.LoginFrag = this.createNewFragment(ofragId, oFragmentName);
				this.getView().addDependent(this.LoginFrag);
			}

			this.LoginFrag.open();
		}, // onLogin End

		onCloseLogin: function () {
			sap.ui.core.Fragment.byId("LoginFrag", "email").setValue("");
			sap.ui.core.Fragment.byId("LoginFrag", "Password").setValue("");
			this.LoginFrag.close();
		},

		onloginSubmit: function () {
			var valid = true; //  
			var userName = sap.ui.core.Fragment.byId("LoginFrag", "email").getValue();
			var password = sap.ui.core.Fragment.byId("LoginFrag", "Password").getValue();

			if (userName == "") {
				MessageToast.show("User Name can not be empty");
				valid = false;
			}
			if (password == "") {
				MessageToast.show("Password can not be empty");
				valid = false;
			}
			if (valid == true) {
				this.LoginPostData();
			}
		},
		onCloseCustRegiter: function () {
			sap.ui.core.Fragment.byId("CustomerRegisterFrag", "name").setValue("");
			sap.ui.core.Fragment.byId("CustomerRegisterFrag", "phone").setValue("");
			sap.ui.core.Fragment.byId("CustomerRegisterFrag", "email").setValue("");
			sap.ui.core.Fragment.byId("CustomerRegisterFrag", "Password").setValue("");
			sap.ui.core.Fragment.byId("CustomerRegisterFrag", "CPassword").setValue("");
			this.CustomerRegDialogFragment.close();
		}, //onCloseCustRegiter End

		onCustomerRegisterSubmit: function () {
			// Form Validation
			var valid = true; //  

			this.numericRegularExpression = /([0-9])/;

			// Name Field Validation
			var name = sap.ui.core.Fragment.byId("CustomerRegisterFrag", "name").getValue();
			if (name == "") {
				MessageToast.show("Name can not be empty");
				valid = false;
			}
			if (!isNaN(name)) {
				MessageToast.show("Name can not have a number");

				valid = false;
			}
			if (this.numericRegularExpression.test(name)) {
				MessageToast.show("Alphanumeric Name is not allowed");

				valid = false;
			}

			// Email Field Validation
			var email = sap.ui.core.Fragment.byId("CustomerRegisterFrag", "email").getValue();
			if (email === "") {
				MessageToast.show("Email cant be empty");

				valid = false;
			} else if (/^[a-zA-Z0-9]+$/.test(email)) {
				MessageToast.show("Email should have @ character");

				valid = false;
			} else if (/^([a-zA-Z0-9@]{2,5})$/.test(email)) {
				MessageToast.show("Email should have 2 char after @ symbol");

				valid = false;
			} else if (/^([a-zA-Z0-9_\@]+)$/.test(email)) {
				MessageToast.show("Email should have . symbol");

				valid = false;
			}
			// Email Regular Expression
			var emailRegularExpression =
				/^(([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5}){1,25})+([;.](([a-zA-Z0-9_\-\.]+)@{[a-zA-Z0-9_\-\.]+0\.([a-zA-Z]{2,5}){1,25})+)*$/;
			if (emailRegularExpression.test(email) === false) {
				MessageToast.show("Email should have 2 char after . symbol");

				valid = false;
			}

			// Phone Number Validation
			var phone = sap.ui.core.Fragment.byId("CustomerRegisterFrag", "phone").getValue();
			if (phone === "") {
				MessageToast.show("phone no. cann't be empty");

				valid = false;
			}
			var numericRegularExpression = /^[0][1-9]\d{9}$|^[1-9]\d{9}$/;
			if (numericRegularExpression.test(phone) === false) {
				MessageToast.show("phone number should have only 10 digits");

				valid = false;
			}

			var password = sap.ui.core.Fragment.byId("CustomerRegisterFrag", "Password").getValue();
			var confirmPassword = sap.ui.core.Fragment.byId("CustomerRegisterFrag", "CPassword").getValue();

			if (password == "") {
				MessageToast.show("Password can not be empty");
				valid = false;
			}
			if (password.length < 5) {
				MessageToast.show("Password Should Contain atleast 5 characters");
				valid = false;
			}
			if (password.length > 15) {
				MessageToast.show("Password Should Contain only 15 characters");
				valid = false;
			}
			if (confirmPassword == "") {
				MessageToast.show("Confirm Password can not be empty");
				valid = false;
			}

			if (password != confirmPassword & confirmPassword != "" & password != "") {
				MessageToast.show("Password does not match the confirm password.");
				valid = false;
			}

			if (valid == true) {
				this.CustomerRegisterPostData();
			}
		},
		createNewFragment: function (sFragmentID, sFragmentName) {
			//Fragment Creaaion
			var oFragment = sap.ui.xmlfragment(sFragmentID, sFragmentName, this);
			return oFragment;
		}, //createNewFragment End

		CustomerRegisterPostData: function () {
			// Sending Data to backend LoadData Function
			var Name = sap.ui.core.Fragment.byId("CustomerRegisterFrag", "name").getValue();
			var phone = sap.ui.core.Fragment.byId("CustomerRegisterFrag", "phone").getValue();
			var email = sap.ui.core.Fragment.byId("CustomerRegisterFrag", "email").getValue();
			var password = sap.ui.core.Fragment.byId("CustomerRegisterFrag", "Password").getValue();

			var ePass = window.btoa(password);

			var oPostData = {
				"name": Name,
				"phoneNo": phone,
				"email": email,
				"passWord": ePass,
			};
			var oHeader = {
				"Content-Type": "application/json;charset=utf-8"
			};
			var oCustomerRegSendDataModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oCustomerRegSendDataModel, "oCustomerRegSendDataModel");
			oCustomerRegSendDataModel.loadData("/postService/customer/save", JSON.stringify(oPostData), true, "POST", false, false, oHeader);
			oCustomerRegSendDataModel.attachRequestCompleted(function (oEvent) {

				var checkStatus = oEvent.mParameters.errorobject.responseText;

				if (checkStatus == "customer added") {
					sap.ui.core.Fragment.byId("CustomerRegisterFrag", "name").setValue("");
					sap.ui.core.Fragment.byId("CustomerRegisterFrag", "phone").setValue("");
					sap.ui.core.Fragment.byId("CustomerRegisterFrag", "email").setValue("");
					sap.ui.core.Fragment.byId("CustomerRegisterFrag", "Password").setValue("");
					sap.ui.core.Fragment.byId("CustomerRegisterFrag", "CPassword").setValue("");
					this.CustomerRegDialogFragment.close();
					MessageToast.show("Successfully Registered");
				} else if (checkStatus == "customer already exists") {
					MessageToast.show("Customer is already exists");
				} else {
					MessageToast.show("Somthing is Wrong Please Try Again");
				}

			}.bind(this));
			oCustomerRegSendDataModel.attachRequestFailed(function (oEvent) {
				//            alert("Error");
			});

		}, //postData End

		LoginPostData: function () {
			// Sending Data to backend LoadData Function
			var email = sap.ui.core.Fragment.byId("LoginFrag", "email").getValue();
			var password = sap.ui.core.Fragment.byId("LoginFrag", "Password").getValue();
			var ePass = window.btoa(password);
			var oPostData = {
				"email": email,
				"passWord": ePass
			};
			var oHeader = {
				"Content-Type": "application/json;charset=utf-8"
			};
			var oCustomerLoginSendDataModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oCustomerLoginSendDataModel, "oCustomerLoginSendDataModel");
			oCustomerLoginSendDataModel.loadData("/postService/customer/login", JSON.stringify(oPostData), true, "POST", false, false, oHeader);
			oCustomerLoginSendDataModel.attachRequestCompleted(function (oEvent) {

				var checkStatus = oEvent.mParameters.errorobject.responseText;

				if (checkStatus == "login Success") {
					sap.ui.core.Fragment.byId("LoginFrag", "email").setValue("");
					sap.ui.core.Fragment.byId("LoginFrag", "Password").setValue("");
					this.LoginFrag.close();
					MessageToast.show("Successfully Login");

					var customerData = {
						"email": email,
					};

					var oModel = new sap.ui.model.json.JSONModel(customerData);
					this.getOwnerComponent().setModel(oModel, "customerData");
					// OR sap.ui.getCore().setModel(oModel, "viewCartData");
					var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
					oRouter.navTo("Restraurant");
				} else {
					MessageToast.show("Username Passward Does not Matched");
				}

			}.bind(this));
			oCustomerLoginSendDataModel.attachRequestFailed(function (oEvent) {
				//            alert("Error");
			});
		},
		onAdminLoginSubmit: function () {
			var valid = true; //  
			var userName = sap.ui.core.Fragment.byId("AdminLoginFrag", "email").getValue();
			var password = sap.ui.core.Fragment.byId("AdminLoginFrag", "Password").getValue();

			if (userName == "") {
				MessageToast.show("User Name can not be empty");
				valid = false;
			}
			if (password == "") {
				MessageToast.show("Password can not be empty");
				valid = false;
			}
			if (valid == true) {
				this.AdminLoginPostData();
			}

		},
		AdminLoginPostData: function () {

			var email = sap.ui.core.Fragment.byId("AdminLoginFrag", "email").getValue();
			var password = sap.ui.core.Fragment.byId("AdminLoginFrag", "Password").getValue();
			var ePass = window.btoa(password);
			var oPostData = {
				"adminEmail": email,
				"adminPassword": ePass
			};
			var oHeader = {
				"Content-Type": "application/json;charset=utf-8"
			};
			var oAdminLoginSendDataModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oAdminLoginSendDataModel, "oAdminLoginSendDataModel");
			oAdminLoginSendDataModel.loadData("/postService/admin/login", JSON.stringify(oPostData), true, "POST", false, false, oHeader);
			oAdminLoginSendDataModel.attachRequestCompleted(function (oEvent) {

				var checkStatus = oEvent.mParameters.errorobject.responseText;

				if (checkStatus == "login Success") {
					sap.ui.core.Fragment.byId("AdminLoginFrag", "email").setValue("");
					sap.ui.core.Fragment.byId("AdminLoginFrag", "Password").setValue("");
					this.AdminLoginDialogFragment.close();
					MessageToast.show("Successfully Login");
					this.oRouter.navTo("Admin");
				} else {
					MessageToast.show("Invalid Usename Password");
				}

			}.bind(this));
			oAdminLoginSendDataModel.attachRequestFailed(function (oEvent) {
				//            alert("Error");
			});
		},
		ondriverLoginSubmit: function () {
			var valid = true; //  
			var userName = sap.ui.core.Fragment.byId("DriverLoginFrag", "email").getValue();
			var password = sap.ui.core.Fragment.byId("DriverLoginFrag", "Password").getValue();

			if (userName == "") {
				MessageToast.show("User Name can not be empty");
				valid = false;
			}
			if (password == "") {
				MessageToast.show("Password can not be empty");
				valid = false;
			}
			if (valid == true) {
				this.DriverLoginPostData();
			}

		},
		DriverLoginPostData: function () {
			var email = sap.ui.core.Fragment.byId("DriverLoginFrag", "email").getValue();
			var password = sap.ui.core.Fragment.byId("DriverLoginFrag", "Password").getValue();
			var ePass = window.btoa(password);
			var oPostData = {
				"email": email,
				"password": ePass
			};
			var oHeader = {
				"Content-Type": "application/json;charset=utf-8"
			};
			var oDriverLoginSendDataModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oDriverLoginSendDataModel, "oDriverLoginSendDataModel");
			oDriverLoginSendDataModel.loadData("/postService/driver/login", JSON.stringify(oPostData), true, "POST", false, false, oHeader);
			oDriverLoginSendDataModel.attachRequestCompleted(function (oEvent) {

				var checkStatus = oEvent.mParameters.errorobject.responseText;

				if (checkStatus == "login Success") {
					sap.ui.core.Fragment.byId("DriverLoginFrag", "email").setValue("");
					sap.ui.core.Fragment.byId("DriverLoginFrag", "Password").setValue("");
					this.DriverLoginDialogFragment.close();
					MessageToast.show("Successfully Login");

					var driverData = {
						"email": email,
					};

					var oModel = new sap.ui.model.json.JSONModel(driverData);
					this.getOwnerComponent().setModel(oModel, "driverData");
					// OR sap.ui.getCore().setModel(oModel, "viewCartData");

					var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
					oRouter.navTo("Driver");
				} else {
					MessageToast.show("Username Passward Does not Matched");
				}

			}.bind(this));
			oDriverLoginSendDataModel.attachRequestFailed(function (oEvent) {
				//            alert("Error");
			});
		}

	});
});