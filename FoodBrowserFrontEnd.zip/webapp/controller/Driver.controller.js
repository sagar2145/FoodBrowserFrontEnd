sap.ui.define([
	'jquery.sap.global',
	'sap/m/MessageToast',
	'sap/ui/core/Fragment',
	'sap/ui/core/mvc/Controller',
	'sap/ui/model/Filter',
	'sap/ui/model/json/JSONModel',
	'sap/base/Log'
], function (jQuery, MessageToast, Fragment, Controller, Filter, JSONModel, Log) {
	"use strict";
	var orderId;
	var driverEmail;
	return Controller.extend("com.sumit.project.FoodBrowser.controller.Driver", {

		onInit: function () {
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.attachRoutePatternMatched(function (oEvent) {
				if (oEvent.getParameter("name") === "Driver") {
				
				}
			});
		
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("Driver").attachMatched(this._onRouteMatched, this);

		},
		_onRouteMatched: function (oEvent) {

			var oModel = this.getView().getModel("driverData");
			 driverEmail = oModel.oData.email;
			var oPostData = {
				"email": driverEmail
			};
			var oHeader = {
				"Content-Type": "application/json;charset=utf-8"
			};
			var oLoginUserDetailsDataModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oLoginUserDetailsDataModel, "oLoginUserDetailsDataModel");
			oLoginUserDetailsDataModel.loadData("/postService/driver/getDrivBy", JSON.stringify(oPostData), true, "POST", false, false,
				oHeader);
			oLoginUserDetailsDataModel.attachRequestCompleted(function (oEvent) {

				var userData = oLoginUserDetailsDataModel.getData();
				var userName = userData.driverName;
				orderId = userData.orderId;
				this.orderDetailsGetData();
				this.getView().getModel("oLoginUserDetailsDataModel").setProperty("/userName", userName);

				// Welcome User Fragment
				var oFragmentName = "com.sumit.project.FoodBrowser.fragment.welcomeUser";
				var ofragId = "welcomeUser";
				if (!this.welcomeUserDialogFragment) {
					this.welcomeUserDialogFragment = this.createNewFragment(ofragId, oFragmentName);
					this.getView().addDependent(this.welcomeUserDialogFragment);
				}
				this.welcomeUserDialogFragment.open();
				setTimeout(function () {
					this.welcomeUserDialogFragment.close();
				}.bind(this), 1000);

			}.bind(this));
			oLoginUserDetailsDataModel.attachRequestFailed(function (oEvent) {
				//            alert("Error");
			});
			// OR var oModel = sap.ui.getCore().getModel("viewCartData");

			// Order Details Get Mthod

		},

		onChangePassword: function () {
		
			var oFragmentName = "com.sumit.project.FoodBrowser.fragment.changePassword";
			var ofragId = "changePasswordFrag";
			if (!this.changePasswordDialogFragment) {
				this.changePasswordDialogFragment = this.createNewFragment(ofragId, oFragmentName);
				this.getView().addDependent(this.changePasswordDialogFragment);
			}
			this.changePasswordDialogFragment.open();

		},
		onCloseChangePassword: function () {

			sap.ui.core.Fragment.byId("changePasswordFrag", "OldPassword").setValue("");
			sap.ui.core.Fragment.byId("changePasswordFrag", "NewPassword").setValue("");
			sap.ui.core.Fragment.byId("changePasswordFrag", "CPassword").setValue("");
			this.changePasswordDialogFragment.close();
		},
		onChangePasswordSubmit: function () {
			var valid = true;
			var oldPassword = sap.ui.core.Fragment.byId("changePasswordFrag", "OldPassword").getValue();
			var newPassword = sap.ui.core.Fragment.byId("changePasswordFrag", "NewPassword").getValue();
			var confirmPassword = sap.ui.core.Fragment.byId("changePasswordFrag", "CPassword").getValue();

			if (oldPassword == "") {
				MessageToast.show("Old Password can not be empty");
				valid = false;
			}

			if (newPassword == "") {
				MessageToast.show("New Password can not be empty");
				valid = false;
			}
			if (confirmPassword == "") {
				MessageToast.show("Confirm Password can not be empty");
				valid = false;
			}

			if (newPassword != confirmPassword & confirmPassword != "" & newPassword != "") {
				MessageToast.show("Password does not match the confirm password.");
				valid = false;
			}
			if (valid == true) {
				this.changePasswordPostData();
			}
		},
		changePasswordPostData: function () {
			var oldPassword = sap.ui.core.Fragment.byId("changePasswordFrag", "OldPassword").getValue();
			var newPassword = sap.ui.core.Fragment.byId("changePasswordFrag", "NewPassword").getValue();

			oldPassword = window.btoa(oldPassword);
			newPassword = window.btoa(newPassword);

			var oPostData = {
				"password": oldPassword,
				"email": driverEmail,
				"newPass": newPassword
			};
			var oHeader = {
				"Content-Type": "application/json;charset=utf-8"
			};
			var oChangePasswordDataModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oChangePasswordDataModel, "oChangePasswordDataModel");
			oChangePasswordDataModel.loadData("/postService/driver/passUpdate", JSON.stringify(oPostData), true, "POST", false, false,
				oHeader);
			oChangePasswordDataModel.attachRequestCompleted(function (oEvent) {

				var checkStatus = oEvent.mParameters.errorobject.responseText;

				if (checkStatus == "password updated") {
					sap.ui.core.Fragment.byId("changePasswordFrag", "OldPassword").setValue("");
					sap.ui.core.Fragment.byId("changePasswordFrag", "NewPassword").setValue("");
					sap.ui.core.Fragment.byId("changePasswordFrag", "CPassword").setValue("");
					this.changePasswordDialogFragment.close();
					MessageToast.show("Your Password Successfully Updated");
				} else if (checkStatus == "enter correct password") {
					MessageToast.show("Old Password Not Corrent");
				} else {
					MessageToast.show("Somthing Went Wrong Please Try Again");
				}

			}.bind(this));
			oChangePasswordDataModel.attachRequestFailed(function (oEvent) {
				//            alert("Error");
			});
		},
		onDiveredBtn: function (oEvent) {
			debugger;
			var oPostData = {
				"orderId": orderId,
			};
			var oHeader = {
				"Content-Type": "application/json;charset=utf-8"
			};
			var oAssignOrderSendDataModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oAssignOrderSendDataModel, "oAssignOrderSendDataModel");
			oAssignOrderSendDataModel.loadData("/postService/admin/orderStatus", JSON.stringify(oPostData), true, "POST", false, false, oHeader);
			oAssignOrderSendDataModel.attachRequestCompleted(function (oEvent) {

				var checkStatus = oEvent.mParameters.errorobject.responseText;
				if (checkStatus == "order updated") {
					orderId = 0;
					this.orderDetailsGetData();
					MessageToast.show("Order Upadeted As Dilivered  ");
				} else {
					MessageToast.show("Somthing is Wrong Please Try Again");
				}

			}.bind(this));
			oAssignOrderSendDataModel.attachRequestFailed(function (oEvent) {
				//            alert("Error");
			});

		},
		orderDetailsGetData: function () {

			var oOrderPostData = {
				"orderId": orderId
			};
			var oHeader = {
				"Content-Type": "application/json;charset=utf-8"
			};
			var oOrderDetailsDataModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oOrderDetailsDataModel, "oOrderDetailsDataModel");
			oOrderDetailsDataModel.loadData("/postService/admin/getOrderBy", JSON.stringify(oOrderPostData), true, "POST", false, false,
				oHeader);
			oOrderDetailsDataModel.attachRequestCompleted(function (oEvent) {
				
				var orderData = oOrderDetailsDataModel.getData();
				var orderList = [];
				orderList.push(orderData);

				this.getView().getModel("oOrderDetailsDataModel").setData(orderList);

			}.bind(this));
			oOrderDetailsDataModel.attachRequestFailed(function (oEvent) {
				//            alert("Error");
			});
		},
		createNewFragment: function (sFragmentID, sFragmentName) {
			// Create Fragment 
			var oFragment = sap.ui.xmlfragment(sFragmentID, sFragmentName, this);
			return oFragment;
		}, //createNewFragment End
		onLogOut: function () {
			this.oRouter.navTo("RouteHome");
			MessageToast.show("Successfully LogOut");
		},
		onOrientationChange: function (oEvent) {
			var bLandscapeOrientation = oEvent.getParameter("landscape"),
				sMsg = "Orientation now is: " + (bLandscapeOrientation ? "Landscape" : "Portrait");
			MessageToast.show(sMsg, {
				duration: 5000
			});
		},

		onPressNavToDetail: function (oEvent) {
			this.getSplitAppObj().to(this.createId("detailDetail"));
		},

		onPressDetailBack: function () {
			this.getSplitAppObj().backDetail();
		},

		onPressMasterBack: function () {
			this.getSplitAppObj().backMaster();
		},

		onPressGoToMaster: function () {
			this.getSplitAppObj().toMaster(this.createId("master2"));
		},

		onListItemPress: function (oEvent) {
			var sToPageId = oEvent.getParameter("listItem").getCustomData()[0].getValue();

			this.getSplitAppObj().toDetail(this.createId(sToPageId));
		},

		onPressModeBtn: function (oEvent) {
			var sSplitAppMode = oEvent.getSource().getSelectedButton().getCustomData()[0].getValue();

			this.getSplitAppObj().setMode(sSplitAppMode);
			MessageToast.show("Split Container mode is changed to: " + sSplitAppMode, {
				duration: 5000
			});
		},

		getSplitAppObj: function () {
			var result = this.byId("SplitAppDemo");
			if (!result) {
				Log.info("SplitApp object can't be found");
			}
			return result;
		}

	});

});